package com.javatechie.spring.batch.config;

import com.javatechie.spring.batch.entity.Customer;
import org.springframework.batch.item.ItemProcessor;

public class CustomerProcessor implements ItemProcessor<Customer,Customer> {

    @Override
    public Customer process(Customer customer) throws Exception {
        if (customer == null) {
            return null;
        }
        
        if (customer.getCountry() == null || customer.getCountry().trim().isEmpty()) {
            return null;
        }
        
        if (customer.getFirstName() == null || customer.getFirstName().trim().isEmpty()) {
            return null;
        }
        
        if (customer.getLastName() == null || customer.getLastName().trim().isEmpty()) {
            return null;
        }
        
        if (customer.getEmail() == null || customer.getEmail().trim().isEmpty()) {
            return null;
        }
        
        if (customer.getCountry().equals("United States")) {
            return customer;
        } else {
            return null;
        }
    }
}
